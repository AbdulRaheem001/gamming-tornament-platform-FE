// // import React from 'react'
import Sidebar from "./Components/sidebar";

import React, { useState, useEffect } from "react";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Box from "@mui/material/Box";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import FormControl from "@mui/material/FormControl";
import RadioGroup from "@mui/material/RadioGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import axios from "axios";
import InputLabel from "@mui/material/InputLabel";

const TournamentList = () => {
    const [searchText, setSearchText] = useState("");
    const [searchStatus, setSearchStatus] = useState("All");
    const [openDialogBox, setOpenDialogBox] = useState(false);
    const [projectName, setProjectName] = useState("");
    const [tournamentName, setTournamentName] = useState("");
    const [discipline, setDiscipline] = useState("");
    const [platformName, setPlatformName] = useState("");
    const [teamSize, setTeamSize] = useState("");
    const [participationType, setParticipationType] = useState("team");
    const [timezone, setTimezone] = useState("");
    const [gameData, setgameData] = useState([]);
    const [tournaments, setTournaments] = useState([
        {
            id: 1,
            name: "Tournament 1",
            status: "Publish",
            date: "2023-09-25",
        },
        {
            id: 2,
            name: "Tournament 2",
            status: "Draft",
            date: "2023-10-10",
        },
        {
            id: 3,
            name: "Tournament 3",
            status: "Publish",
            date: "2023-09-18",
        },
        {
            id: 4,
            name: "Tournament 4",
            status: "Draft",
            date: "2023-10-05",
        },
    ]);
    useEffect(() => {
        axios
            .get("http://localhost:8000/game/allGames")
            .then((response) => {
                setgameData(response.data);
                console.log("Line 67", response.data);
            })
            .catch((error) => {
                console.error("Error fetching products:", error);
            });
    }, []);
    const filteredTournaments = tournaments.filter((tournament) => {
        const nameMatch = tournament.name
            .toLowerCase()
            .includes(searchText.toLowerCase());
        const statusMatch =
            searchStatus === "All" || tournament.status === searchStatus;
        return nameMatch && statusMatch;
    });

    const handleSearchTextChange = (event) => {
        setSearchText(event.target.value);
    };

    const handleCreateProject = () => {
        alert(`Creating project: ${projectName}`);
        setOpenDialogBox(false);
    };

    const handleCloseDialog = () => {
        setOpenDialogBox(false);
    };

    const handleStatusChange = (event) => {
        setSearchStatus(event.target.value);
    };

    const handleOpenDialogBox = () => {
        setOpenDialogBox(true);
    };

    return (
        <>
            <Box sx={{ display: "flex" }}>
                <Sidebar />
                <Box component="main" sx={{ flexGrow: 1, p: 3, paddingTop: "64px" }}>
                    <div style={{ padding: "1rem" }}>
                        <Box
                            display="flex"
                            justifyContent="space-between"
                            alignItems="center"
                            sx={{
                                padding: "1rem",
                            }}
                        >
                            <Typography variant="h4">My Tournaments</Typography>
                        </Box>
                        <Box mt={2}>
                            <Typography variant="h5">Tournament List</Typography>
                            <TextField
                                label="Search by Name"
                                variant="outlined"
                                margin="normal"
                                fullWidth
                                value={searchText}
                                onChange={handleSearchTextChange}
                            />
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={4}>
                                    <TextField
                                        select
                                        label="Status"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        value={searchStatus}
                                        onChange={handleStatusChange}
                                    >
                                        <MenuItem value="All">All</MenuItem>
                                        <MenuItem value="Publish">Publish</MenuItem>
                                        <MenuItem value="Draft">Draft</MenuItem>
                                    </TextField>
                                </Grid>
                                <Grid item xs={12} sm={4}>
                                    <TextField
                                        label="Start Date"
                                        type="date"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        value={searchStatus}
                                        onChange={handleStatusChange}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={4}>
                                    <TextField
                                        label="End Date"
                                        type="date"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        value={searchStatus}
                                        onChange={handleStatusChange}
                                    />
                                </Grid>
                            </Grid>
                        </Box>
                        <Box mt={2}>
                            {filteredTournaments.map((tournament) => (
                                <Card
                                    key={tournament.id}
                                    variant="outlined"
                                    sx={{ margin: "1rem" }}
                                >
                                    <CardContent>
                                        <Typography variant="h6">{tournament.name}</Typography>
                                        <Typography variant="body2" color="textSecondary">
                                            Status: {tournament.status}
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary">
                                            Date: {tournament.date}
                                        </Typography>
                                        <Button variant="outlined" color="primary">
                                            Edit
                                        </Button>
                                    </CardContent>
                                </Card>
                            ))}
                        </Box>
                    </div>
                </Box>
            </Box>
        </>
    );
};

export default TournamentList;
