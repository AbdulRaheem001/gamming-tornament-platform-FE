import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  Button,
  Typography,
  Grid,
  Box,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import Navbar from "../Commen/Navbar";
import Footer from "../Commen/Footer";
import axios from "axios";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import Sidebar from "./Components/sidebar";
// Game Card component
// const GameCard = ({ gameName, imageUrl,gameFee,gamePlatform }) => (
//     <>
//   <Card
//     style={{
//       width: '100%',
//       maxWidth: 345,
//       backgroundColor: 'white',
//       border: '1px solid green',
//       borderRadius: '12px',
//       boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)',
//       transition: '0.3s',
//     }}
//   >
//     <img src={imageUrl} alt="Game" style={{ width: '100%', height: 'auto' }} />

//     <CardContent>
//     <center>
//       <Typography variant="h6" color="textPrimary" component="div">
//          <strong>{gameName}</strong>
//       </Typography>
//       <Typography variant="h6" color="textPrimary" component="div">
//          <strong>{gamePlatform}</strong>
//       </Typography>
//       <Typography variant="h6" color="textPrimary" component="div">
//         Fee : <strong>${gameFee}</strong>
//       </Typography>
//       </center>
//       <Button
//         variant="contained"
//         color="primary"
//         fullWidth
//         style={{ marginTop: 16, backgroundColor: '#45f884', color: '#000' }}
//       >
//         Creat Tournament
//       </Button>
//     </CardContent>
//   </Card>
//   </>

// );

const CreatTournament = () => {
  const [platform, setPlatform] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [openDialogBox, setOpenDialogBox] = useState(false);
  const [timezone, setTimezone] = useState("");
  const [projectName, setProjectName] = useState("");
  const [tournamentName, setTournamentName] = useState("");
  const [platformName, setPlatformName] = useState("");
  const [teamSize, setTeamSize] = useState("");
  const handlePlatformChange = (event) => {
    setPlatform(event.target.value);
  };
  const [gameData, setgameData] = useState([]);

  const toBase64 = (arr) => {
    return btoa(
      arr.reduce((data, byte) => data + String.fromCharCode(byte), "")
    );
  };

  useEffect(() => {
    axios
      .get("http://localhost:8000/game/allGames")
      .then((response) => {
        setgameData(response.data);
        console.log("Line 67", response.data);
      })
      .catch((error) => {
        console.error("Error fetching products:", error);
      });
  }, []);

  const processedGame = gameData.map((game) => ({
    ...game,
    imageUrl: game.image
      ? `data:image/png;base64,${toBase64(game.image.data)}`
      : null,
  }));

  const mappedGames = Array.isArray(processedGame) ? processedGame : [];
  const filteredGames = mappedGames
    ? mappedGames.filter((item) => {
        return (
          (platform === "All" || item.platform === platform) &&
          (searchTerm === "" ||
            item.name.toLowerCase().includes(searchTerm.toLowerCase()))
        );
      })
    : [];
  const formattedGames = filteredGames
    ? filteredGames.map((item) => ({
        ...item,
        image: item.image ? item.image : null,
      }))
    : [];
  console.log(formattedGames);

  const handleCreateProject = () => {
    alert(`Creating project: ${projectName}`);
    setOpenDialogBox(false);
  };

  const handleCloseDialog = () => {
    setOpenDialogBox(false);
  };
  
  const handleOpenDialogBox = () => {
    setOpenDialogBox(true);
  };

  return (
    <>
      <Box sx={{ display: 'flex' }}>
      <Sidebar />
      <Box component="main" sx={{ flexGrow: 1, p: 3, paddingTop: '64px' }}>
      <Box
        style={{
          flexGrow: 1,
          bgcolor: "#f5f5f5",
          marginTop: "30px",
          marginBottom: "30px",
        }}
      >
        <Box
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "16px",
            marginBottom: "20px",
          }}
        >
          <TextField
            label="Search Games"
            variant="outlined"
            style={{ minWidth: "600px" }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <FormControl variant="outlined" style={{ minWidth: "300px" }}>
            <InputLabel>Platform</InputLabel>
            <Select
              value={platform}
              onChange={handlePlatformChange}
              label="Platform"
            >
              <MenuItem value="All">All</MenuItem>
              <MenuItem value="PC">PC</MenuItem>
              <MenuItem value="Mobile">Mobile</MenuItem>
              <MenuItem value="Play-Station">Play-Station</MenuItem>
              <MenuItem value="X-Box">X-Box</MenuItem>
            </Select>
          </FormControl>
        </Box>
        <Grid
          container
          spacing={2}
          style={{
            display: "flex",
            justifyContent: "normal",
            alignItems: "stretch",
            minHeight: "100vh",
            padding: "16px",
          }}
        >
          {formattedGames.map((item) => (
            <Grid item xs={12} sm={6} md={4} lg={3}>
              {/* <GameCard gameName={item.name} imageUrl={item.imageUrl} gameFee={item.fee} gamePlatform={item.platform} /> */}
              <Card
                style={{
                  width: "100%",
                  maxWidth: 345,
                  backgroundColor: "white",
                  border: "1px solid green",
                  borderRadius: "12px",
                  boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
                  transition: "0.3s",
                }}
              >
                <img
                  src={item.imageUrl}
                  alt="Game"
                  style={{ width: '250px', height: '150px', objectFit: 'cover' }}
                />

                <CardContent>
                  <center>
                    <Typography
                      variant="h6"
                      color="textPrimary"
                      component="div"
                    >
                      <strong>{item.name}</strong>
                    </Typography>
                    <Typography
                      variant="h6"
                      color="textPrimary"
                      component="div"
                    >
                      <strong>{item.platform}</strong>
                    </Typography>
                    <Typography
                      variant="h6"
                      color="textPrimary"
                      component="div"
                    >
                      Fee : <strong>${item.fee}</strong>
                    </Typography>
                  </center>
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    style={{
                      marginTop: 16,
                      backgroundColor: "#45f884",
                      color: "#000",
                    }}
                    onClick={handleOpenDialogBox}
                  >
                    Creat Tournament
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
        <Dialog open={openDialogBox} onClose={handleCloseDialog}>
          <DialogTitle>Create New Project</DialogTitle>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  label="Tournament Name"
                  variant="outlined"
                  fullWidth
                  value={tournamentName}
                  onChange={(e) => setTournamentName(e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Number of Participants"
                  variant="outlined"
                  fullWidth
                  value={teamSize}
                  type="number"
                  onChange={(e) => setTeamSize(e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Enter the Fee"
                  variant="outlined"
                  fullWidth
                  value={projectName}
                  type="number"
                  onChange={(e) => setProjectName(e.target.value)}
                />
              </Grid>
                  <Grid item xs={6}>
                    <TextField
                      label="Enter the Prize Pool"
                      variant="outlined"
                      fullWidth
                      value={projectName}
                      type="number"
                      onChange={(e) => setProjectName(e.target.value)}
                    />
                  </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Time and Date"
                  type="datetime-local"
                  variant="outlined"
                  fullWidth
                  // margin="normal"
                  InputLabelProps={{
                    shrink: true, // This will prevent the overlap
                  }}
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button
              variant="contained"
              color="primary"
              onClick={handleCreateProject}
            >
              Create
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
      </Box>
      </Box>
    </>
  );
};

export default CreatTournament;
